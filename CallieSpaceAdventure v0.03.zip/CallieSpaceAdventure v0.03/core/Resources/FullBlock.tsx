<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="FullBlock" tilewidth="24" tileheight="24" tilecount="3" columns="3">
 <image source="../../GameWorkspace1/CallieSpaceAdventure/desktop/Resources/maps/FullBlock.png" width="72" height="24"/>
</tileset>
