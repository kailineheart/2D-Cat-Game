<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="BlockSheet2" tilewidth="24" tileheight="12" tilecount="20" columns="5">
 <image source="../../GameWorkspace1/CallieSpaceAdventure/desktop/Resources/maps/BlockSheet2.png" width="120" height="48"/>
</tileset>
