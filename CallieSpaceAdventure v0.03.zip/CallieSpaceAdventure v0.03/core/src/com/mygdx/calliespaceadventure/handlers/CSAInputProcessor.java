package com.mygdx.calliespaceadventure.handlers;

import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.InputAdapter;

public class CSAInputProcessor extends InputAdapter{
	
	//set value to indicate key is pressed
	public boolean keyDown(int k){
		
		if(k == Keys.LEFT || k == Keys.A ){  //left key binding
			CSAInput.setKey(CSAInput.BUTTON1, true);
		}
		
		if(k == Keys.RIGHT || k == Keys.D){
			CSAInput.setKey(CSAInput.BUTTON2, true); //right key binding
		}
		
		if(k == Keys.SPACE){
			CSAInput.setKey(CSAInput.JUMP, true); //jump key binding
		}
		
		return true;
	}
	
	//set value to indicate key is not pressed
	public boolean keyUp(int k){
		
		if(k == Keys.LEFT || k == Keys.A ){  //left key binding
			CSAInput.setKey(CSAInput.BUTTON1, false);
		}
		
		if(k == Keys.RIGHT || k == Keys.D){
			CSAInput.setKey(CSAInput.BUTTON2, false); //right key binding
		}
		
		if(k == Keys.SPACE){
			CSAInput.setKey(CSAInput.JUMP, false); //jump key binding
		}
		
		return true;
	}

}
