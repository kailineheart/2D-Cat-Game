package com.mygdx.calliespaceadventure.handlers;

public class B2DVariables {
	
	//pixels per meter ratio
	public static final float PPM = 100;

	// category bits - determines collision
	// Notes: there can be a maximum of 15 0000 0000 0000 000X 1 per bit
	// you use category bit to set the type, and mask bit to tell which to collide with
	
	public static final short BIT_BLOCK = 2; //also used for ground as they use same collision
	public static final short BIT_PLATFORM = 4; //half sized blocks
	public static final short BIT_PLAYER = 8; 
	public static final short BIT_BELL = 16;   //collectables
	public static final short BIT_ENEMY = 32;  //for crystal spikes and damagables
	public static final short BIT_PRIZE = 64;
	
	
}
