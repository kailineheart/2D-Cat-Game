<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="win platforms" tilewidth="48" tileheight="27" tilecount="3" columns="3">
 <tileoffset x="0" y="6"/>
 <image source="maps/win platforms.png" width="144" height="27"/>
</tileset>
