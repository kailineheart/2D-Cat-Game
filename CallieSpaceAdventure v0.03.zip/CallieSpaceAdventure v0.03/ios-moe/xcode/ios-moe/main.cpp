#include <MOE/MOE.h>

int main(int argc, char *argv[]) {
    return moevm(argc, argv);
}
