package com.mygdx.calliespaceadventure.entities;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.physics.box2d.Body;
import com.mygdx.calliespaceadventure.main.CallieGame;

public class Player extends B2DSprite{
	
	private int numBells;    //number of bells collected
	private int totalBells;  //total # of bells in level
	
	public Player(Body body){
		super(body);
		
		Texture texture = CallieGame.Rmanager.getTexture("cat");
		TextureRegion[] frames = TextureRegion.split(texture, 24, 24)[0];
		
		setAnimation(frames, 1/10f);
	}
	
	public void render(SpriteBatch sprite, boolean flip){
		sprite.begin();
		
		if(flip){
			sprite.draw(animation.getFrame(), 
				flip ? body.getPosition().x + width/8 : body.getPosition().x, (body.getPosition().y-height/2), 
						flip ? -width : width, height);
		}
		else{
			sprite.draw(animation.getFrame(), 
					body.getPosition().x - width/2, body.getPosition().y-height/2);
		}
		sprite.end();
	}
	
	public void collectBell(){numBells++;}
	public int getNumBells(){return numBells;}
	public int getTotalBells(){return totalBells;}
	public void setTotalBells(int i){this.totalBells = i;}
}
