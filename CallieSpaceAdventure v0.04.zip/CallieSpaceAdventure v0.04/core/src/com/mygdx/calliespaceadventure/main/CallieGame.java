package com.mygdx.calliespaceadventure.main;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.calliespaceadventure.handlers.CSAInput;
import com.mygdx.calliespaceadventure.handlers.CSAInputProcessor;
import com.mygdx.calliespaceadventure.handlers.ResourceManager;
import com.mygdx.calliespaceadventure.handlers.GameStateManager;

public class CallieGame extends ApplicationAdapter {
	
	public static final String TITLE = "Callie's Interplanetary Space Adventure"; //Callie is the name of the cat
	//virtual dimensions of the game screen regardless of actual screen size
	public static final int V_WIDTH = 320;
	public static final int V_HEIGHT = 240;
	public static final int WORLD_WIDTH = 408;
	public static final int WORLD_HEIGHT = 888;
	public static final int SCALE =2;
	
	//variables to help keep track of time as box2d likes a fixed step amount
	public static final float STEP = 1/60f;
	private float accumulator = 0;  //keeps track of amount of time passed
	
	//game state manager
	GameStateManager GSManager;
	
	//resource manager
	public static ResourceManager Rmanager;
	
	//camera and sprite batch for rendering and camera movement
	private SpriteBatch SB;
	private OrthographicCamera camera;
	private OrthographicCamera hudCamera;
	private Viewport viewport;
	
	
	// methods that run the game itself
	@Override
	public void create () {  //initialize variables
		
		//use custom input processor
		Gdx.input.setInputProcessor(new CSAInputProcessor());
		
		//asset related
		Rmanager = new ResourceManager();
		Rmanager.loadTexture("Resources/images/catblock24.png", "cat");
		
		SB = new SpriteBatch();
		
		//initialize cameras
		camera = new OrthographicCamera();
		camera.setToOrtho(false, WORLD_WIDTH, WORLD_HEIGHT);
		camera.update();
		
		hudCamera = new OrthographicCamera();
		hudCamera.setToOrtho(false,V_WIDTH, V_HEIGHT);
		hudCamera.update();
		
		//set world size
		viewport = new FitViewport(WORLD_WIDTH,WORLD_HEIGHT,camera);
		
		//Game State Manager
		GSManager = new GameStateManager(this);
	}

	@Override
	public void resize(int width, int height) {
		viewport.update(width, height);
		
	}

	@Override
	public void render() {  //updates current state of game
		accumulator += Gdx.graphics.getDeltaTime();
		while (accumulator >= STEP){
			accumulator-=STEP;
			GSManager.update(STEP);
			GSManager.render();
			CSAInput.update();
		}
		
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}
	
	//access methods for private variables outside this class
	public SpriteBatch getSpriteBatch(){
		return SB;
	}
		
	public OrthographicCamera getCamera(){
		return camera;
	}
		
	public OrthographicCamera getHUDCamera(){
		return hudCamera;
	}
}