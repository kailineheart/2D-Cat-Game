package com.mygdx.calliespaceadventure.handlers;

import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.Contact;
import com.badlogic.gdx.physics.box2d.ContactImpulse;
import com.badlogic.gdx.physics.box2d.ContactListener;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.Manifold;
import com.badlogic.gdx.utils.Array;

public class CSAContactListener implements ContactListener{
	
	private int numFootContacts;
	private Array<Body> BodiesToRemove;
	
	public CSAContactListener(){
		super();
		BodiesToRemove = new Array<Body>();
	}

	//called when two fixtures collide
	@Override
	public void beginContact(Contact contact) {
		Fixture fa = contact.getFixtureA();
		Fixture fb = contact.getFixtureB();
		
		//if fixture does not exist continue
		if(fa == null|fb == null)return;
		
		// detect which fixture is the foot sensor
		if(fa.getUserData() != null && fa.getUserData().equals("foot")){
			numFootContacts++;
		}
		if(fb.getUserData() != null && fb.getUserData().equals("foot")){
			numFootContacts++;
		}
		
		//detect collision with bell
		if(fa.getUserData() != null && fa.getUserData().equals("bell")){
			//add to remove crystal list
			BodiesToRemove.add(fa.getBody());
		}
		if(fb.getUserData() != null && fb.getUserData().equals("bell")){
			//add to remove crystal list
			BodiesToRemove.add(fb.getBody());
		}
		
		//detect collision with prize
		if(fa.getUserData() != null && fa.getUserData().equals("prize")){
			//to do add win level condition
			System.out.println("you win!");
		}
		if(fb.getUserData() != null && fb.getUserData().equals("prize")){
			//to do add win level condition
			System.out.println("you win!");
		}
	}

	//called when two fixtures no longer collide
	@Override
	public void endContact(Contact contact) {
		Fixture fa = contact.getFixtureA();
		Fixture fb = contact.getFixtureB();
		
		//if fixture does not exist continue
		if(fa == null|fb == null)return;
		
		// detect which fixture is the foot sensor
		if(fa.getUserData() != null && fa.getUserData().equals("foot")){
			numFootContacts--;
		}
		if(fb.getUserData() != null && fb.getUserData().equals("foot")){
			numFootContacts--;
		}
	}

	
	
	//between begincontact and endcontact: not really needed
	@Override
	public void preSolve(Contact contact, Manifold oldManifold) {
		// TODO Auto-generated method stub
		
	}

	//after endcontact: not really needed
	@Override
	public void postSolve(Contact contact, ContactImpulse impulse) {
		// TODO Auto-generated method stub
		
	}
	
	//return value based on if player in contact with ground/platform
	public boolean isPlayerOnGround(){ 
		return numFootContacts > 0;
	}
	
	public Array<Body> getBodiesToRemove(){
		return BodiesToRemove;
	}

}
