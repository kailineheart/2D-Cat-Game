==========================================
READ ME FILE FOR
Callie's Space Adventure Game Prototype
==========================================

This is a prototype for CSA in which bare minimum
functionality is available

controls are

-------------------------
movement controls
-------------------------

A or left arrow : move left

D or right arrow: move right

spacebar: jump


Note: player character is currently only a wire frame box
and not much of the level is currently traversable due to jump
not being high enough, to be adjusted later.