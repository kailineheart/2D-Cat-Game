package com.mygdx.calliespaceadventure.handlers;

public class CSAInput {
	
	//keeps track of the current keys pressed
	public static boolean[] keystate;
	public static boolean[] prevkeystate;
	
	//number of keys to control movement
	public static final int NUM_KEYS = 3;
	public static final int BUTTON1 = 0; //left movement
	public static final int BUTTON2 =1; //right movement
	public static final int JUMP = 2;
	
	//initialize arrays
	static{
		keystate = new boolean[NUM_KEYS];
		prevkeystate = new boolean[NUM_KEYS];
	}
	
	//updating the previous state to current state
	public static void update(){
		for(int i = 0; i<NUM_KEYS; i++){
				prevkeystate[i] = keystate[i];
		}
	}
		
	//allows you to set the current state of the key
	public static void setKey(int i, boolean b){
		keystate[i] = b;
	}
		
	//says if button, indicated by index i, is currently pushed down
	public static boolean isDown(int i){
		return keystate[i];
	}
		
	//returns value if current button is pressed and previous button is not pressed
	public static boolean isPressed(int i){
		return keystate[i] && !prevkeystate[i];
	}
}
