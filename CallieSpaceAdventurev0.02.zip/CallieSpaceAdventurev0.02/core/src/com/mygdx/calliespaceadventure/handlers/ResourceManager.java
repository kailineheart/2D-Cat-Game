package com.mygdx.calliespaceadventure.handlers;

import java.util.HashMap;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;

public class ResourceManager {
	
	private HashMap<String, Texture> textures;
	
	public ResourceManager(){
		textures = new HashMap<String, Texture>();
	}
	
	//loads the texture
	public void loadTexture(String path, String key){
		Texture tex = new Texture(Gdx.files.internal(path));
		textures.put(key, tex);
	}
	
	//returns texture using the given key
	public Texture getTexture(String key){
		return textures.get(key);
	}
	
	public void disposeTexture(String key){
		Texture tex = textures.remove(key);
		if(tex != null) tex.dispose();
	}

}
