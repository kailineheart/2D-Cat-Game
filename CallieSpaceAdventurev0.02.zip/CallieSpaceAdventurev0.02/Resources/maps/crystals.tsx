<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="crystals" tilewidth="24" tileheight="24" tilecount="18" columns="6">
 <image source="../image assets/crystals.png" width="144" height="72"/>
</tileset>
