/** Automatically generated file. DO NOT MODIFY */
package com.mygdx.calliespaceadventure;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}