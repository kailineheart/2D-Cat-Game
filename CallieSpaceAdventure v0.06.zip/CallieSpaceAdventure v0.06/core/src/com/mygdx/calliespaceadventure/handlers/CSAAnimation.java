package com.mygdx.calliespaceadventure.handlers;

import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class CSAAnimation {
	
	private TextureRegion[] frames;
	private int currentFrame; //keeps track of current frame
	
	private float time;       //current time
	private float delay;      //time between frames
	
	private int timesPlayed;  //to limit number of loops if needed
	
	//default constructor
	public CSAAnimation(){
		this.delay = 1/12f; //default delay time
	}
	
	//default delay time constructor
	public CSAAnimation(TextureRegion[] frames){
		setFrames(frames, 1/12f);
	}
	
	public CSAAnimation(TextureRegion[] frames, float delay){
		setFrames(frames, delay);
	}
	
	public void setFrames(TextureRegion[] frames, float delay){
		this.frames = frames;
		this.delay = delay;
		time = 0;
		currentFrame = 0;
		timesPlayed = 0;
	}
	
	//makes animation move forward
	public void update(float delta){
		
		if(delay<=0) return;  //if delay is less than 0 don't run animation
		else time +=delta;    //move forward one step
		
		while(time>=delay){
			step();
		}
	}
	
	//increment animation
	public void step(){
		time-=delay;
		currentFrame++;
		
		if(currentFrame == frames.length){
			currentFrame = 0;
			timesPlayed++;
		}
	}
	
	//returns current frame
	public TextureRegion getFrame(){
		return frames[currentFrame];
	}
	
	//returns number of times animation was played
	public int GetTimesPlayed(){
		return timesPlayed;
	}
	
}
