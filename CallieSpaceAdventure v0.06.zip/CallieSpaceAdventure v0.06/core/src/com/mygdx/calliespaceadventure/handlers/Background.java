package com.mygdx.calliespaceadventure.handlers;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.physics.box2d.Body;
import com.mygdx.calliespaceadventure.main.CallieGame;
import com.mygdx.calliespaceadventure.states.Play;

public class Background {
	
	private int level;
	private Texture texture;
	private Texture tree;
	private Texture leaves;
	private Texture Dleaves;
	
	public Background(){
		this.level = Play.level;
		
		if(level<10){
			texture = CallieGame.Rmanager.getTexture("EasyBG");
			tree = CallieGame.Rmanager.getTexture("Eskeleton");
			leaves = CallieGame.Rmanager.getTexture("Eleaves");
			Dleaves = CallieGame.Rmanager.getTexture("EDLeaves");
		}
		if(level>=10 && level<19){
			texture = CallieGame.Rmanager.getTexture("MedBG");
			tree = CallieGame.Rmanager.getTexture("Mskeleton");
			leaves = CallieGame.Rmanager.getTexture("Mleaves");
			Dleaves = CallieGame.Rmanager.getTexture("MDLeaves");
		}
		if(level>18){
			texture = CallieGame.Rmanager.getTexture("HardBG");
			tree = CallieGame.Rmanager.getTexture("Hskeleton");
			leaves = CallieGame.Rmanager.getTexture("Hleaves");
			Dleaves = CallieGame.Rmanager.getTexture("HDLeaves");
		}
	}
	
	//may simplify this later if proves to be too difficult
	public void render(SpriteBatch sprite, int order){
		
		sprite.begin();
		sprite.draw(texture,0,0); //update with proper coordinates later
		
		//change order of layer of tree and leaves based on position of player
		if(level<10 && order == 0){
			sprite.draw(tree, 0,0);  //update proper coordinates later
			sprite.draw(leaves, 0,0); //update proper coordinates later
		}
		if(level<10 && order == 1){
			sprite.draw(Dleaves, 0,0); //update proper coordinates later
			sprite.draw(tree,0,0);  //update proper coordinates later
		}
		
		if(level>=10 && level < 19 && order == 0){
			sprite.draw(tree, 0,0);  //update proper coordinates later
			sprite.draw(leaves, 0,0); //update proper coordinates later
		}
		if(level>=10 && level < 19 && order == 1){
			sprite.draw(Dleaves, 0,0); //update proper coordinates later
			sprite.draw(tree, 0,0);  //update proper coordinates later
		}
		
		if(level>18 && order == 0){
			sprite.draw(tree, 0,0);  //update proper coordinates later
			sprite.draw(leaves, 0,0); //update proper coordinates later
		}
		if(level>18 && order == 1){
			sprite.draw(Dleaves, 0,0); //update proper coordinates later
			sprite.draw(tree, 0,0);  //update proper coordinates later
		}
		
		sprite.end();
		
	}

}
