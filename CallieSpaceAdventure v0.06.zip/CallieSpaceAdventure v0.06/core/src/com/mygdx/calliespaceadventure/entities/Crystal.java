package com.mygdx.calliespaceadventure.entities;

public class Crystal {

}
