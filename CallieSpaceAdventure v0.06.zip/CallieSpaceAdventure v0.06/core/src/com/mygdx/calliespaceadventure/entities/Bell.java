package com.mygdx.calliespaceadventure.entities;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.physics.box2d.Body;
import com.mygdx.calliespaceadventure.main.CallieGame;

public class Bell extends B2DSprite{
	
	public Bell (Body body){
		
		super(body);
		
		Texture texture = CallieGame.Rmanager.getTexture("bell");
		TextureRegion[] frames = TextureRegion.split(texture, 18, 18)[0];
		setAnimation(frames, 1/8f);

	}

}
