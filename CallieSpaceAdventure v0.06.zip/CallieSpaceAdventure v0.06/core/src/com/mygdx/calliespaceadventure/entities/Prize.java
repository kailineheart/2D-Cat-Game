package com.mygdx.calliespaceadventure.entities;

import java.util.Random;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.mygdx.calliespaceadventure.main.CallieGame;
import com.mygdx.calliespaceadventure.states.Play;

public class Prize {
	
	private Body body;
	private int width = 42;
	private int height = 30;
	private TextureRegion[] prizes;
	private Random rand;
	private int e; //easy prize
	private int m; //medium prize
	private int h; //hard prize
	
	public Prize (Body body){
		this.body = body;
		Texture texture = CallieGame.Rmanager.getTexture("prize");
		prizes = TextureRegion.split(texture, width, height)[0];
		rand = new Random();
		e = rand.nextInt(3); //pick random prize in range
		m = rand.nextInt(3)+3;
		h = rand.nextInt(3)+7;
	}
	
	public void render(SpriteBatch sprite){

		sprite.begin();
		if(Play.level<10){ //randomly generate prize for easy levels 
			sprite.draw(prizes[e],
					body.getPosition().x - width/2, body.getPosition().y-height/2);
		}
		if(Play.level>=10 &&Play.level<19){ //randomly generate prizes for med levels
			sprite.draw(prizes[m],
					body.getPosition().x - width/2, body.getPosition().y-height/2);
		}
		if(Play.level>=19){ //randomly generate prizes for hard levels
			sprite.draw(prizes[h],
					body.getPosition().x - width/2, body.getPosition().y-height/2);
		}
		
		sprite.end();
	}
	
	public void setSpecialPrize(SpriteBatch sprite){ //set prize to unicorn
		sprite.begin();
		if(Play.level<10){ //randomly generate prize for easy levels 
			sprite.draw(prizes[3],
					body.getPosition().x - width/2, body.getPosition().y-height/2);
		}
		if(Play.level>=10 &&Play.level<19){ //randomly generate prizes for med levels
			sprite.draw(prizes[7],
					body.getPosition().x - width/2, body.getPosition().y-height/2);
		}
		if(Play.level>=19){ //randomly generate prizes for hard levels
			sprite.draw(prizes[11],
					body.getPosition().x - width/2, body.getPosition().y-height/2);
		}
		
		sprite.end();
	}
	
	public Body getBody(){return body;}
	
	public Vector2 getPosition(){return body.getPosition();}
}
