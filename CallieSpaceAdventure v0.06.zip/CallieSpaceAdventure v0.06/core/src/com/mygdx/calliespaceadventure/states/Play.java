package com.mygdx.calliespaceadventure.states;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.MapLayer;
import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.ChainShape;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.MassData;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer.Cell;
import com.mygdx.calliespaceadventure.entities.Bell;
import com.mygdx.calliespaceadventure.entities.Player;
import com.mygdx.calliespaceadventure.entities.Prize;
import com.mygdx.calliespaceadventure.handlers.B2DVariables;
import com.mygdx.calliespaceadventure.handlers.Background;
import com.mygdx.calliespaceadventure.handlers.BoundedCamera;
import com.mygdx.calliespaceadventure.handlers.CSAInput;
import com.mygdx.calliespaceadventure.handlers.GameStateManager;
import com.mygdx.calliespaceadventure.handlers.CSAContactListener;
import com.mygdx.calliespaceadventure.main.CallieGame;

import static com.mygdx.calliespaceadventure.handlers.B2DVariables.PPM;
import static com.mygdx.calliespaceadventure.handlers.B2DVariables.BIT_PLATFORM;
import static com.mygdx.calliespaceadventure.handlers.B2DVariables.BIT_PLAYER;
import static com.mygdx.calliespaceadventure.handlers.B2DVariables.BIT_BLOCK;
import static com.mygdx.calliespaceadventure.handlers.B2DVariables.BIT_BELL;
import static com.mygdx.calliespaceadventure.handlers.B2DVariables.BIT_ENEMY;
import static com.mygdx.calliespaceadventure.handlers.B2DVariables.BIT_PRIZE;

public class Play extends GameState{
	
	private boolean debug = false;
	
	private World gworld;
	private Box2DDebugRenderer B2DRenderer;
	
	private BoundedCamera B2DCamera;
	
	private Player player;
	private Array<Bell> bells;
	private Prize prize;
	
	private Background BG;
	private int order = 0; //effects layering of BG image
	
	private CSAContactListener cl;
	
	private boolean isFlipped = false;
	
	private TiledMap tilemap;
	private OrthogonalTiledMapRenderer mapRenderer; //for rendering tiled map
	
	//to get size of the map and tile size
	private int tileMapWidth;
	private int tileMapHeight;
	private int tileWidth;
	private int tileHeight;
	
	
	public static int level; //for selecting which level to load

	public Play(GameStateManager GSManager){
		super(GSManager);
		
		//creating the world the game takes place in
		gworld = new World(new Vector2(0,-9.81f*15), true);
		cl = new CSAContactListener();
		gworld.setContactListener(cl); //makes world use custom contact listener
		
		//will render all the bodies in the world
		B2DRenderer = new Box2DDebugRenderer();
		
//------------------------------------------------------------------------------------------------------		
		//temporary to test map loading
		tilemap = new TmxMapLoader().load("Resources/maps/CSATestLevel.tmx"); 
		//Integer.class converts the return value into an integer
		tileMapWidth = tilemap.getProperties().get("width", Integer.class); //width in tiles
		tileMapHeight = tilemap.getProperties().get("height", Integer.class); //height in tiles
		tileWidth = tilemap.getProperties().get("tilewidth", Integer.class); //tile width in pixels
		tileHeight = tilemap.getProperties().get("tileheight", Integer.class); //tile height in pixels
		mapRenderer = new OrthogonalTiledMapRenderer(tilemap);
//----------------------------------------------------------------------------------------------------
		
		//load tile map
		// loadTileMap();
		BG = new Background();
		
		//create Box2D entities/tiles
	    createPlayer();
	    createBells();
		createPrize();
	    
		createHalfBlocks();
		createFullBlocks();
		createCrystals();
		createWinPlatform();
		createGround();
		
		//set up box2d camera to handle scaling
		B2DCamera = new BoundedCamera();
		B2DCamera.setToOrtho(false, CallieGame.V_WIDTH, CallieGame.V_HEIGHT);
		B2DCamera.setBounds(0,(tileMapWidth * tileWidth), 0, (tileMapHeight * tileHeight));

	}
	

	//may need to adjust player character size to be slightly smaller than a full block
	//temporary making it return playerbody until entity class is created to allow player jump
	private void createPlayer(){
		//initialize body/fixture creation variables
		BodyDef bdef = new BodyDef();
		Body body;
		PolygonShape shape = new PolygonShape();
		FixtureDef fdef = new FixtureDef();
				
		//create player body
		bdef.position.set(80, 80); //starting position
		bdef.type = BodyType.DynamicBody;
		body = gworld.createBody(bdef);
				
		//create player fixture
		shape.setAsBox(8, 10,new Vector2(-5,0), 0); //set shape to box and set size
		fdef.shape = shape;
		fdef.filter.categoryBits = BIT_PLAYER; //set category
		fdef.filter.maskBits = BIT_BLOCK | BIT_PLATFORM | BIT_BELL | BIT_ENEMY;  //set mask
		body.createFixture(fdef).setUserData("player"); //set ID
		
		//create foot sensor for player
		shape.setAsBox(6, 2, new Vector2(-5,-10),0); //use version with vector to alter position
		fdef.shape = shape;
		fdef.filter.categoryBits = BIT_PLAYER; //set category
		fdef.filter.maskBits = BIT_BLOCK | BIT_PLATFORM;  //set mask 
		fdef.isSensor = true; //indicate fixture is sensor
		body.createFixture(fdef).setUserData("foot");
		
		//create player
		player = new Player(body); //the class connects the body to the animation
		
		body.setUserData(player); //gives the body a reference to the class
		
		//set mass of player character to 1 kg
		MassData mass = body.getMassData();
		mass.mass = 1;
		body.setMassData(mass);
		

	}
	
	//reads in tile map layers for full blocks and half size blocks
	//sets up Box2D bodies for them
	public void loadTileMap(){  
		//load map
		try{
			//insert file path here for level testing
			tilemap = new TmxMapLoader().load("Resources/maps/level" + level + ".tmx"); 
		}
		catch(Exception e){ //in case map doesn't load correctly or file not found
			System.out.println("Could not load: Reasources/maps/level" +level+".tmx"); //error message
			Gdx.app.exit();
		}
		//acquiring the map size and tile size
		//Integer.class converts the return value into an integer
		tileMapWidth = tilemap.getProperties().get("width", Integer.class); //width in tiles
		tileMapHeight = tilemap.getProperties().get("height", Integer.class); //height in tiles
		tileWidth = tilemap.getProperties().get("tilewidth", Integer.class); //tile width in pixels
		tileHeight = tilemap.getProperties().get("tileheight", Integer.class); //tile height in pixels
		
		mapRenderer = new OrthogonalTiledMapRenderer(tilemap);
		
		
	}
	//method for generating the tiled map layer for half blocks (12px tall blocks)
	private void createHalfBlocks(){
		
		//load layer and check if empty
		TiledMapTileLayer layer = (TiledMapTileLayer) tilemap.getLayers().get("half block");
		if(layer == null) return;
		
		//get tile size
		float tileheight = layer.getTileHeight();
		float tilewidth = layer.getTileWidth();
		
		//go through all cells in layer
		for(int row = 0; row<layer.getHeight();row++){
			for(int col = 0;col<layer.getWidth(); col++){
				
				//get cell
				Cell cell = layer.getCell(col, row); //x is col, y is row
				
				//check that there is a cell
				if(cell == null)continue;
				if(cell.getTile()== null) continue;
				
				//create body from cell
				BodyDef bdef = new BodyDef();
				bdef.type = BodyType.StaticBody;
				//it's offset by a half to center the body
				bdef.position.set((col+0.5f) * tilewidth, (row+0.5f) * tileheight);
				
				//chain shape is used since player entities tend to get stuck on polygon shapes
				ChainShape cs = new ChainShape();
				Vector2[] v = new Vector2[5];
				v[0] = new Vector2(-tilewidth/2, -tileheight/2);
				v[1] = new Vector2(-tilewidth/2, tileheight/2);
				v[2] = new Vector2(tilewidth/2, tileheight/2);
				v[3] = new Vector2(tilewidth/2, -tileheight/2);
				v[4] = new Vector2(-tilewidth/2, -tileheight/2);
				cs.createChain(v);
				
				//create fixture
				FixtureDef fdef = new FixtureDef();
				fdef.friction = 0.6f;
				fdef.shape = cs;
				fdef.filter.categoryBits = BIT_PLATFORM;
				fdef.filter.maskBits = BIT_PLAYER;
				gworld.createBody(bdef).createFixture(fdef);
				cs.dispose();
			}
		}
		
	}
	
	//method for generating the tiled map layer for full blocks (24px tall blocks)
	private void createFullBlocks(){
		//load layer and check if empty
		TiledMapTileLayer layer = (TiledMapTileLayer) tilemap.getLayers().get("full block");
		if(layer == null) return;
		
		//get tile size
		float tileheight = layer.getTileHeight();
		float tilewidth = layer.getTileWidth();
		
		//go through all cells in layer
		for(int row = 0; row<layer.getHeight();row++){
			for(int col = 0;col<layer.getWidth(); col++){
				
				//get cell, x is col and y is row
				Cell cell = layer.getCell(col, row);
				
				//check that there is a cell
				if(cell == null)continue;
				if(cell.getTile()== null) continue;
				
				//create body from cell
				BodyDef bdef = new BodyDef();
				bdef.type = BodyType.StaticBody;
				//it's offset by a half to center the body
				bdef.position.set((col+0.5f) * tilewidth, (row+1f) * tileheight);
				
				//chain shape is used since player entities tend to get stuck on polygon shapes
				ChainShape cs = new ChainShape();
				Vector2[] v = new Vector2[5];
				v[0] = new Vector2(-tilewidth/2, -tileheight);
				v[1] = new Vector2(-tilewidth/2, tileheight);
				v[2] = new Vector2(tilewidth/2, tileheight);
				v[3] = new Vector2(tilewidth/2, -tileheight);
				v[4] = new Vector2(-tilewidth/2, -tileheight);
				cs.createChain(v);
				
				//create fixture
				FixtureDef fdef = new FixtureDef();
				fdef.friction = 0.6f;
				fdef.shape = cs;
				fdef.filter.categoryBits = BIT_BLOCK;
				fdef.filter.maskBits = BIT_PLAYER;
				gworld.createBody(bdef).createFixture(fdef);
				cs.dispose();
				
			}
		}
		
	}
	
	//method for generating the tiled map layer for the crystal spikes
	private void createCrystals(){
		//load layer and check if empty
		TiledMapTileLayer layer = (TiledMapTileLayer) tilemap.getLayers().get("crystal");
		if(layer == null) return;
		
		//get tile size
		float tileheight = layer.getTileHeight();
		float tilewidth = layer.getTileWidth();
		
		//go through all cells in layer
		for(int row = 0; row<layer.getHeight();row++){
			for(int col = 0;col<layer.getWidth(); col++){
				
				//get cell
				Cell cell = layer.getCell(col, row); //x is col, y is row
				
				//check that there is a cell
				if(cell == null)continue;
				if(cell.getTile()== null) continue;
				
				//create body from cell
				BodyDef bdef = new BodyDef();
				bdef.type = BodyType.StaticBody;
				
				//it's offset by a half and 0.7 to center the body
				//in a way that the box hugs them more
				bdef.position.set((col+0.5f) * tilewidth, (row+0.7f) * tileheight);
				Body body = gworld.createBody(bdef);
				
				//this isn't a chain shape as it's a enemy tile
				PolygonShape shape = new PolygonShape();
				shape.setAsBox(12, 10);
				
				//create fixture
				FixtureDef fdef = new FixtureDef();
				fdef.shape = shape;
				fdef.isSensor = true;
				fdef.filter.categoryBits = BIT_ENEMY;
				fdef.filter.maskBits = BIT_PLAYER;
				body.createFixture(fdef).setUserData("crystal");
				
				//unsure if need to use crystal class to create a circular reference right now
				//since this is not an animated entity but does cause a change in state to occur
				
				shape.dispose();
			}
		}
		
	}
	
	//method for generating the tiled map layer for the collectables
	//which reside on an object layer
	private void createBells(){ 
		
		//create list of bells
		 bells = new Array<Bell>();
		
		//load layer and check if empty
		MapLayer layer = tilemap.getLayers().get("bells");
		if(layer == null) return;
		
		BodyDef bdef = new BodyDef();
		FixtureDef fdef = new FixtureDef();
		
		//load bell objects
		for(MapObject mo : layer.getObjects()){
			//define and create body
			bdef.type = BodyType.StaticBody;
			
			//get x and y coordinates of object location and set position
			float x = mo.getProperties().get("x", Float.class);
			float y = mo.getProperties().get("y", Float.class);
			bdef.position.set(x,y);
			
			Body body = gworld.createBody(bdef);
			
			//create fixture
			CircleShape cshape = new CircleShape();   //can be any shape
			cshape.setRadius(7);
			fdef.shape = cshape;
			
			fdef.isSensor = true;
			fdef.filter.categoryBits = BIT_BELL;
			fdef.filter.maskBits = BIT_PLAYER;
			body.createFixture(fdef).setUserData("bell");
			
			//create circular reference between entity class and body
			Bell b = new Bell(body);
			body.setUserData(b);       //set body user data here to bell object
			bells.add(b);              //add bell to list
			
			cshape.dispose();
			
		}
	}
	
	//generates the win platform layer
	public void createWinPlatform(){
		//load layer and check if empty
		TiledMapTileLayer layer = (TiledMapTileLayer) tilemap.getLayers().get("win platform"); //temp changed to see if name problem
		if(layer == null) return;
		
		//get tile size
		float tileheight = layer.getTileHeight();
		float tilewidth = layer.getTileWidth();
		
		//go through all cells in layer
		for(int row = 0; row<layer.getHeight();row++){
			for(int col = 0;col<layer.getWidth(); col++){
				
				//get cell
				Cell cell = layer.getCell(col, row); //x is col, y is row
				
				//check that there is a cell
				if(cell == null)continue;
				if(cell.getTile()== null) continue;
				
				//create body from cell
				BodyDef bdef = new BodyDef();
				bdef.type = BodyType.StaticBody;
				//it's offset by a half to center the body
				bdef.position.set((col+1f) * tilewidth, (row+0.5f) * tileheight);
				
				//chain shape is used since player entities tend to get stuck on polygon shapes
				PolygonShape shape = new PolygonShape();
				shape.setAsBox(16, 5);
				
				//create fixture
				FixtureDef fdef = new FixtureDef();
				fdef.shape = shape;
				fdef.filter.categoryBits = BIT_BLOCK;
				fdef.filter.maskBits = BIT_PLAYER;
				gworld.createBody(bdef).createFixture(fdef);
				shape.dispose();
				
			}
		}
	}
	
	//generates the prize which is a object layer
	public void createPrize(){
		
		//load layer and check if empty
		MapLayer layer = tilemap.getLayers().get("prize");
		if(layer == null) return;
		
		//load object, use this for now until find better means of loading single object
		for(MapObject mo : layer.getObjects()){
			//define and create body
			BodyDef bdef = new BodyDef();
			bdef.type = BodyType.StaticBody;
			
			//get x and y coordinates of object location and set position
			float x = mo.getProperties().get("x", Float.class);
			float y = mo.getProperties().get("y", Float.class);
			bdef.position.set(x,y);
			
			Body body = gworld.createBody(bdef);
			
			//create fixture
			FixtureDef fdef = new FixtureDef();
			PolygonShape shape = new PolygonShape();
			shape.setAsBox(18, 15);
			fdef.shape = shape;
			
			fdef.isSensor = true;
			fdef.filter.categoryBits = BIT_PRIZE;
			fdef.filter.maskBits = BIT_PLAYER;
			body.createFixture(fdef).setUserData("prize");
			
			prize = new Prize(body);
			body.setUserData(prize);
	
			shape.dispose();
			
		}
		
	}
	
	public void createGround() {  //generate line object to act as ground layer
	// figure out how to create line or chain shape to act as ground
		//create body
		BodyDef bdef = new BodyDef();
		bdef.type = BodyType.StaticBody;	
		
		//chain shape is used since player entities tend to get stuck on polygon shapes
		ChainShape cs = new ChainShape();
		Vector2[] v = new Vector2[4];
		v[0] = new Vector2(0, 32); //temporarily using other numbers to check object creation
		v[1] = new Vector2(33, 47);
		v[2] = new Vector2(374, 47);
		v[3] = new Vector2(407, 32);
		cs.createChain(v);
		
		//create fixture
		FixtureDef fdef = new FixtureDef();
		fdef.friction = 0.6f;
		fdef.shape = cs;
		fdef.filter.categoryBits = BIT_BLOCK;
		fdef.filter.maskBits = BIT_PLAYER;
		
		gworld.createBody(bdef).createFixture(fdef);
		
		cs.dispose();
		
	}
	
	@Override
	public void handleInput() {
		
		//test button presses work
		if(CSAInput.isPressed(CSAInput.BUTTON1)){
		//	System.out.println("pressed left button");
			isFlipped = false;
			player.getBody().applyForceToCenter(-20*PPM,0, true);
		}
		if(CSAInput.isPressed(CSAInput.BUTTON2)){
		//	System.out.println("pressed right button");
			isFlipped = true;
			player.getBody().applyForceToCenter(20*PPM,0, true);
			
		}
		if(CSAInput.isPressed(CSAInput.JUMP)){
			if(cl.isPlayerOnGround()){
				player.getBody().applyForceToCenter(0,350*PPM,true); //temp to be replaced with player object body
				//the values are in newtons: x,  y, wake boolean
			}
		}
		
	}

	@Override
	public void update(float deltaTime) {
		//update user input
		handleInput();
		
		//updating the world, values used are what's generally recommended 
		gworld.step(deltaTime, 6, 2);
		
		//update player
		player.update(deltaTime);
		
		//update bells
		for(int i = 0; i<bells.size; i++){
			bells.get(i).update(deltaTime);
		}
		
		//remove bells
		Array<Body> bodies = cl.getBodiesToRemove();
		
		for(int i = 0; i<bodies.size;i++){
			Body b = bodies.get(i);
			bells.removeValue((Bell) b.getUserData(), true);
			// true means it's using == instead of .equals()
			gworld.destroyBody(b);
			player.collectBell();
		}
		bodies.clear();  //you need to clear the list afterwards
		
	}

	@Override
	public void render() {
		
		//clear the screen
		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
		Gdx.gl20.glClear(GL20.GL_COLOR_BUFFER_BIT);
		camera.update();
	
		//draw background
		BG.render(SB, 1);
		
		//draw the tiled map
		mapRenderer.setView(camera); //camera is from GameState Class
		mapRenderer.render();
		
		//draw player
		SB.setProjectionMatrix(camera.combined);
		player.render(SB, isFlipped);
		
		//draw bells
		for(int i = 0; i<bells.size; i++){
			bells.get(i).render(SB);
		}
		
		//draw prize
		prize.render(SB);
		
		//draw the debug box2d world
		if(debug){
		B2DRenderer.render(gworld, camera.combined); //rendering of all bodies
		}
	/*	if(debug){  //version that includes bounded camera
			B2DCamera.setPosition(player.getPosition().x + CallieGame.V_WIDTH/4, 
			player.getPosition().y + CallieGame.V_HEIGHT/4);
			B2DCamera.update();
			B2DRenderer.render(gworld, B2DCamera.combined);
			
		}
		*/
	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}

}
